import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.Locale;

public class TipCalculatorController {

    @FXML private TextField billAmountField;
    @FXML private TextField tipPercentageField;
    @FXML private Label tipAmountLabel;
    @FXML private Label errorLabel;

    @FXML
    private void calculateTip() {
        errorLabel.setText("");
        tipAmountLabel.setText("");

        try {
            double bill = Double.parseDouble(billAmountField.getText().trim());
            double percent = Double.parseDouble(tipPercentageField.getText().trim());

            if (bill < 0 || percent < 0) {
                errorLabel.setText("Error: Values cannot be negative.");
                return;
            }

            double tip = bill * percent / 100.0;
            tipAmountLabel.setText(String.format(Locale.US, "Tip Amount: $%.2f", tip));
        } catch (NumberFormatException e) {
            errorLabel.setText("Error: Invalid input. Please enter numbers.");
        }
    }

    @FXML
    private void reset() {
        billAmountField.clear();
        tipPercentageField.clear();
        tipAmountLabel.setText("");
        errorLabel.setText("");
    }
}
